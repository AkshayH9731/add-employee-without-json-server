import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {
  employees = [
    {id:"1000", name:"rahul", salary:"5400", department:"java"},
    {id:"54", name:"Progmer", salary:"54", department:"py"},
    {id:"545", name:"Prograr", salary:"54", department:"psp"},
    {id:"4588", name:"Programer", salary:"54", department:"dssdf"},                 
  ];
  akshay:any={};
  akshay2:any={};
  msg:any="";
  constructor() { }

  ngOnInit(): void {
  }
  addEmployee(){
    this.employees.push(this.akshay);
    this.akshay = {};
    this.msg = " Employee Record is successfully added..... "; 

  }
  deleteEmployee(i: number){
    if(window.confirm('Are you sure you want to delete this item ')){
    this.employees.splice(i,1);
    this.msg = "Record is successfully deleted..... ";
    }
  }
  myValue: any;
  editEmployee(k: number){
    this.akshay2.id = this.employees[k].id;
    this.akshay2.name = this.employees[k].name;
    this.akshay2.salary = this.employees[k].salary;
    this.akshay2.department = this.employees[k].department;
    this.myValue = k;

  }
  updateEmployee(){
    let k= this.myValue;
    for(let i=0; i<this.employees.length;i++){
      if(i==k){
        this.employees[i]= this.akshay2;
        this.akshay2 = {};
        this.msg = "Employee Record is successfully updated..... ";
      }

    }

  }
  clickMe(){
    this.msg = "";
  }
}
